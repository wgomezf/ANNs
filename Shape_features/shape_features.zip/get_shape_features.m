clearvars; close all; clc;

% Opt: 1 - Malignant tumor and 0 - Benign tumor
opt = 1; 
if opt
    fname = 'bus_1050-r.mat';
else
    fname = 'bus_1012-l';
end

% Load file
load(fullfile(pwd,fname));

% Display images
figure('color','w')
subplot 121;
imshow(I);
title(sprintf('BUS image with %s tumor',info.tumor.pathology));
subplot 122;
imshow(BW);
title('Tumor mask');

% Calculate shape features
[x,feats] = shape_feats(BW);
for i = 1:numel(x)
    fprintf('x[%d] - %s: %0.2f\n',i, feats{i},x(i));
end